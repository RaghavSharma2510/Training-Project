<template>
  <br />
  <nav>
    <div class="filtersList">
      <div class="filter">
        <label for="assetFilter">Asset</label>
        <select name="assetFilter" id="assetFilter" v-model="assetFilter">
          <option value="" selected>Filter By Asset</option>
          <option v-for="asset in assets" :key="asset.id" :value="asset.id">
            {{ asset.name }}
          </option>
        </select>
      </div>
      <div class="filter">
        <label for="userFilter">User</label>
        <select name="userFilter" id="userFilter" v-model="userFilter">
          <option value="" selected>Filter By User</option>
          <option v-for="sup in supervisors" :key="sup.id" :value="sup.id">
            {{ sup.firstName }} {{ sup.lastName }}(Supervisor)
          </option>
          <option
            v-for="stud in students"
            :key="stud.id"
            :value="stud.id"
            v-show="isSupervisor"
          >
            {{ stud.firstName }} {{ stud.lastName }}(Student)
          </option>
        </select>
      </div>
      <div class="filter">
        <label for="dateFilter">Date</label>
        <input type="date" v-model="dateFilter" placeholder="Filter by Date" />
      </div>
    </div>
  </nav>
  <div class="container" v-if="!currentData.length">
    <div class="empty">
      <img src="../assets/alien spaceship-rafiki 3.png" alt="" />
      <h1>No Data Found !!!</h1>
    </div>
  </div>
  <div class="cardList-container" v-else>
    <div v-for="trans in currentData" :key="trans.id">
      <card-view :trans="trans" :isSupervisor="isSupervisor" :assets="assets">
      </card-view>
    </div>
  </div>
</template>
<script>
import CardView from "./CardView.vue";

export default {
  mounted() {
    this.getTransactionData();
  },

  props: ["isSupervisor", "assets", "currentUser"],
  components: { CardView },
  inject: ["students", "supervisors"],

  watch: {
    currentUser() {
      this.assetFilter = "";
      this.userFilter = "";
      this.dateFilter = "";
      this.getTransactionData(true);
      // console.log(this.transactions);
    },
    userFilter() {
      this.getTransactionData(true);
    },
    assetFilter() {
      this.getTransactionData(true);
    },
    dateFilter() {
      this.getTransactionData(true);
    },
  },
  data() {
    return {
      userFilter: "",
      assetFilter: "",
      dateFilter: "",
      transactions: [],
      trans: {},
    };
  },
  methods: {
    getTransactionData() {
      // console.log(this.assetFilter);
      let count = 0;
      let url = "http://localhost:3000/transactions?";
      if (!this.isSupervisor) {
        url += `studentId=${this.currentUser}`;
        count = 1;
      }
      if (this.assetFilter !== "") {
        if (count) {
          url += "&";
        }
        url += `assetId=${this.assetFilter}`;
        count = 1;
      }
      if (this.userFilter !== "") {
        if (count) url += "&";
        if (
          this.supervisors.find((value) => {
            return value.id === this.userFilter;
          })
        ) {
          url += `loaningSupervisorId=${this.userFilter}`;
        } else {
          url += `studentId=${this.userFilter}`;
        }
        count = 1;
      }
      // if (this.dateFilter !== "") {
      //   if (count) url += "&";
      //   url += `loanDate=${this.dateFilter}`;
      //   count = 1;
      // }
      // console.log(url);

      fetch(url)
        .then((response) => {
          if (response.ok) {
            return response.json();
          }
        })
        .then((data) => {
          const res = [];
          for (const id of data) {
            res.push(id);
          }

          let arr = [...res];
          if (this.dateFilter !== "") {
            this.transactions = arr.filter((item) => {
              var extractedDate = new Date(item.loanDate);
              var year = extractedDate.getUTCFullYear();
              var month = ("0" + (extractedDate.getUTCMonth() + 1)).slice(-2);
              var day = ("0" + extractedDate.getUTCDate()).slice(-2);
              var formattedDate = year + "-" + month + "-" + day;
              // console.log(formattedDate);
              return formattedDate === this.dateFilter;
            });
          } else this.transactions = [...res];
        })
        .catch((err) => {
          console.log("Something Went Wrong!!! " + err);
        });
    },
    // showData() {
    //   this.currentData = this.transactions;
    //   console.log(this.currentData);
    //   console.log(this.currentUser);
    // },
  },
  computed: {
    currentData() {
      return this.transactions;
    },
  },
};
</script>
<style scoped>
#cogwheel {
  width: 10px;
  height: 10px;
}
.filtersList {
  display: block;
  margin-left: 74px;
  margin-bottom: 20px;
}
.filter label {
  font-size: 10px;
  display: block;
  text-align: start;
  margin-left: 5px;
  color: black;
  margin-bottom: 10px;
  font-weight: bolder;
}
.filter {
  display: inline-flex;
  flex-direction: column;
  margin-right: 50px;
}
.filter select {
  height: 35px;
  width: 140px;
  font-size: 10px;
  color: grey;
  box-shadow: 0px 1px 5px grey;
  border-radius: 9px;
}
option {
  color: black;
  font-weight: bold;
  font-family: "Comic Neue", cursive;
  margin-left: 20px;
}
.filter option:hover {
  color: grey;
}
.filter input {
  height: 32px;
  width: 140px;
  font-size: 10px;
  color: grey;
  border-radius: 9px;
  box-shadow: 0px 1px 5px grey;
}
.cardList-container {
  /* columns: 13rem auto;
  column-gap: 20px;
  margin: 42px 126px; */
  display: flex;
  flex-direction: column;
  max-height: 10000px;
  flex-wrap: wrap;
  width: 100vw;
  max-width: 100vw;
}

.empty img {
  height: 535px;
  width: auto;
}
.empty h1 {
  color: #487172;
  display: inline;
  margin-left: -410px;
  align-self: center;
}
.container {
  width: 100%;
  height: 74vh;
  display: flex;
  justify-content: center;
  align-items: center;
  margin-left: -126px;
}
</style>
