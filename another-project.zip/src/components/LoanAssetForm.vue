<template>
  <form @submit.prevent="submitForm">
    <div class="modal">
      <div class="modal-content">
        <h2>Loan Asset</h2>
        <div class="options">
          <label for="supervisor">Supervisor <br /></label>
          <select name="supervisor" id="supervisor" v-model="supId">
            <option value="" selected>Select</option>
            <option v-for="sup in supervisors" :key="sup.id" :value="sup.id">
              {{ sup.firstName }} {{ sup.lastName }}
            </option>
          </select>
        </div>
        <br />
        <div class="options">
          <label for="student">Student <br /></label>
          <select name="student" id="student" v-model="studId">
            <option value="" selected>Select</option>
            <option v-for="stud in students" :key="stud.id" :value="stud.id">
              {{ stud.firstName }} {{ stud.lastName }}
            </option>
          </select>
        </div>
        <br />
        <div class="options">
          <label for="Asset">Asset <br /></label>
          <select name="Asset" id="Asset" v-model="assetId">
            <option value="" selected>Select</option>
            <option v-for="asset in assets" :key="asset.id" :value="asset.id">
              {{ asset.name }}
            </option>
          </select>
        </div>
        <br />
        <div class="options">
          <label for="issueDate">Issue Date</label>
          <input
            type="date"
            name="issueDate"
            id="issueDate"
            v-model="issueDate"
          />
        </div>
        <p v-if="isInvalidInput">Please enter all values correctly</p>
        <p v-if="error">{{ error }}</p>
        <div class="btn">
          <button role="button" type="button" @click="closeLoan" class="cancel">
            <b>Cancel</b>
          </button>

          <button role="button" type="submit" class="submit">
            <b>Save</b>
          </button>
        </div>
      </div>
    </div>
  </form>
</template>
<script>
export default {
  data() {
    return {
      transId: this.uuidv4(),
      supId: "",
      studId: "",
      assetId: "",
      issueDate: "",
      assetName: "",
      studName: "",
      supName: "",
      isInvalidInput: false,
      error: null,
    };
  },
  watch: {
    assetId(value) {
      let selectedAsset = this.assets.find((asset) => {
        return asset.id === value;
      });
      this.assetName = selectedAsset ? selectedAsset.name : "";
    },
    studId(value) {
      let selectedstud = this.students.find((stud) => stud.id === value);
      this.studName = selectedstud
        ? selectedstud.firstName + " " + selectedstud.lastName
        : "";
    },
    supId(value) {
      let selectedSup = this.supervisors.find((sup) => sup.id === value);
      this.supName = selectedSup
        ? selectedSup.firstName + " " + selectedSup.lastName
        : "";
    },
  },
  methods: {
    submitForm() {
      if (
        this.supId === "" ||
        this.studId === "" ||
        this.assetId === "" ||
        this.issueDate === ""
      ) {
        this.isInvalidInput = true;
        return;
      } else {
        this.invalidInput = false;
        this.error = null;
        fetch("http://localhost:3000/transactions", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            id: this.transId,
            transactionType: "Loan",
            loaningSupervisorId: this.supId,
            loaningSupervisorname: this.supName,
            studentId: this.studId,
            studentname: this.studName,
            assetId: this.assetId,
            assetName: this.assetName,
            loanDate: this.issueDate,
            receivingSupervisorId: null,
            receivingSupervisorname: null,
            returnDate: null,
          }),
        })
          .then((response) => {
            if (response.ok) {
              this.studId = "";
              this.supId = "";
              this.assetId = "";
              this.issueDate = "";
              this.assetName = "";
              this.studName = "";
              this.supName = "";
              this.isInvalidInput = false;
              this.error = null;
            }
          })
          .catch((error) => {
            console.log("Failed" + error.message);
          });
        this.closeLoan();
        this.rerender();
      }
    },
    uuidv4() {
      return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
        /[xy]/g,
        function (c) {
          const r = (Math.random() * 16) | 0,
            v = c == "x" ? r : (r & 0x3) | 0x8;
          return v.toString(16);
        }
      );
    },
  },

  props: ["assets"],

  inject: ["supervisors", "students", "rerender", "closeLoan"],
};
</script>
<style scoped>
.modal {
  display: block;
  position: fixed;
  z-index: 2;
  padding-top: 100px;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  overflow: auto;
  background-color: rgb(0, 0, 0);
  background-color: rgba(0, 0, 0, 0.4);
}
.modal-content {
  background-color: #fefffe;
  padding: 20px;
  border-radius: 20px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
  max-width: 276px;
  width: 100%;
  /* max-height: 372px; */
  /* height: 100%; */
  height: auto;
  margin: 100px auto;
  /* z-index: 2; */
}
h2 {
  margin-bottom: -3px;
  margin-top: 2px;
}
p {
  margin-bottom: 0;
}
.options label {
  font-weight: bolder;
  font-size: 13px;
  display: block;
  text-align: start;
  margin-left: 5px;
  /* color: grey; */
  margin-bottom: 5px;
  margin-top: 14px;
}
.options {
  display: inline-flex;
  flex-direction: column;
  margin-right: 50px;
}
.options select {
  height: 35px;
  width: 266px;
  font-size: 10px;
  /* color: grey; */
  box-shadow: 0px 0.5px 1px grey;
  border-radius: 9px;
}
option {
  font-weight: bold;
  color: rgb(91, 76, 76);
  font-size: larger;
}
.options input {
  height: 33px;
  width: 261px;
  font-size: 13px;
  /* color: grey; */
  /* box-shadow: 0px 0.5px 1px grey; */
  border-radius: 9px;
}
.btn {
  display: flex;
  justify-content: space-between;
}
.cancel {
  border-radius: 4px;
  background-color: white;
  border: 1px solid grey;
  width: 139px;
  height: 37px;
  margin-top: 19px;
}
.submit {
  border-radius: 4px;
  background-color: #487172;
  border: 1px solid grey;
  width: 139px;
  height: 37px;
  margin-top: 19px;
  color: white;
  margin-left: 10px;
}
</style>
