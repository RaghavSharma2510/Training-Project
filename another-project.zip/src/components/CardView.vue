<template>
  <div
    :class="[
      { card: !expand },
      { expandGreen: expandGreen },
      { expandOrange: expandOrange },
    ]"
    @click="toggleExpand"
  >
    <div class="edit">
      <img
        v-if="isSupervisor && trans.transactionType === 'Loan'"
        src="../assets/edit-3-svgrepo-com.svg"
        alt=""
        :class="trans.transactionType === 'Return' ? 'greenImg' : 'orangeImg'"
        @click="openEditForm"
      />
      <img
        v-else
        src="../assets/student.svg"
        alt=""
        :class="trans.transactionType === 'Return' ? 'greenImg' : 'orangeImg'"
      />
    </div>
    <img v-if="expand" src="../assets/laptop.jpg" alt="" class="laptop" />
    <div class="id">
      {{ trans.id }}
    </div>
    <div class="assetName">{{ trans.assetName }}</div>
    <div class="studentName">{{ trans.studentname }}</div>
    <div class="badgeList">
      <div class="badge" v-if="trans.receivingSupervisorname">
        <b>Return Date: </b>{{ formattedReturnDate(trans.returnDate) }}
      </div>
      <div class="badge">
        <b>Issue Date: </b>{{ formattedReturnDate(trans.loanDate) }}
      </div>
      <div class="badge" v-if="!trans.receivingSupervisorname || expand">
        <b>Loaning Supervisor: </b>{{ trans.loaningSupervisorname }}
      </div>
      <div class="badge" v-if="trans.receivingSupervisorname">
        <b>Receiving Supervisor: </b>
        {{ trans.receivingSupervisorname }}
      </div>
      <div class="badge" v-if="expand">
        <b>Asset ID: </b> {{ trans.assetId }}
      </div>
      <div class="badge" v-if="expand"><b>Model: </b>{{ trans.assetName }}</div>
    </div>
    <div class="return" v-if="isSupervisor && trans.transactionType === 'Loan'">
      <img
        src="../assets/download-square-svgrepo-com.svg"
        alt=""
        @click="openReturnForm"
        id="returnImg"
      />
    </div>
  </div>
  <return-asset-form v-if="returnForm" :trans="trans"></return-asset-form>
  <edit-form v-if="editForm" :trans="trans" :assets="assets"></edit-form>
</template>
<script>
import ReturnAssetForm from "./ReturnAssetForm.vue";
import EditForm from "./EditForm.vue";
export default {
  components: {
    ReturnAssetForm,
    EditForm,
  },
  props: ["trans", "isSupervisor", "assets"],
  provide() {
    return {
      close: this.close,
      closeEdit: this.closeEdit,
    };
  },
  data() {
    return {
      returnForm: false,
      editForm: false,
      expand: false,
      expandGreen: false,
      expandOrange: false,
    };
  },
  methods: {
    toggleExpand(event) {
      event.stopPropagation();
      this.expand = !this.expand;
      if (this.trans.transactionType === "Loan") {
        this.expandOrange = !this.expandOrange;
      } else {
        this.expandGreen = !this.expandGreen;
      }
    },
    formattedReturnDate(lol) {
      const returnDate = new Date(lol);
      const year = returnDate.getFullYear();
      const month = String(returnDate.getMonth() + 1).padStart(2, "0");
      const day = String(returnDate.getDate()).padStart(2, "0");
      return `${year}-${month}-${day}`;
    },
    openReturnForm(event) {
      event.stopPropagation();
      this.returnForm = true;
      return false;
    },
    openEditForm(event) {
      event.stopPropagation();
      this.editForm = true;
      return false;
    },
    close(event) {
      event.stopPropagation();
      this.returnForm = false;
      return false;
    },
    closeEdit(event) {
      event.stopPropagation();
      this.editForm = false;
      return false;
    },
  },
};
</script>
<style scoped>
.expandOrange {
  border: 2.5px solid orange;
  display: block;
  width: 190px;
  height: auto;
  padding: 15px;
  /* box-shadow: 0 5px 5px orange; */
  margin: 10px;
  border-radius: 14px;
  overflow: auto;
  grid-column: 1 / -1;
  cursor: pointer;
}
.expandGreen {
  border: 2.5px solid green;
  display: block;
  width: 190px;
  height: auto;
  padding: 15px;
  /* box-shadow: 0 5px 5px green; */
  margin: 10px;
  border-radius: 14px;
  overflow: auto;
  grid-row: span 2;
  /* position: absolute; */
  background: white;
  cursor: pointer;
}
.card {
  display: inline-block;
  width: 190px;
  height: auto;
  max-height: 215px;
  padding: 15px;
  border: 1px solid #ccc;
  box-shadow: 0 4px 8px -2px grey;
  margin: 10px;
  border-radius: 14px;
  overflow: auto;
  cursor: pointer;
}
.id {
  font-size: 9.5px;
  margin-bottom: 10px;
  font-weight: 1000;
  color: rgb(70, 67, 67);
  display: flexbox;
}

.assetName {
  font-size: 20px;
  font-weight: bold;
  margin-bottom: 10px;
}
.studentName {
  font-size: 15px;
  font-weight: bold;
  margin-bottom: 10px;
}
.badgeList {
  display: flexbox;
  justify-content: flex-start;
}
.badge {
  /* display: inline-flex; */
  justify-content: center;
  height: auto;
  width: auto;
  font-weight: 500;
  font-size: 10px;
  border-radius: 7px;
  padding: 7px 7px 7px 7px;
  background-color: #f8f8f9;
  border-color: #d1d4dc;
  border: 1px solid #d1d4dc;
  margin: 10px 10px 10px 0px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.4);
}
.edit {
  display: flex;
  justify-content: flex-end;
  z-index: 1;
  position: absolute;
  margin-left: 170px;
}
template {
  display: none;
}
.greenImg {
  background-color: #5dba8c;
  height: 18px;
  width: 18px;
  align-self: center;
  z-index: 1;
  margin: 0;
  padding: 3px 3px 3px 3px;
  border-radius: 50%;
}
.orangeImg {
  background-color: #ea653e;
  height: 18px;
  width: 18px;
  align-self: center;
  z-index: 1;
  margin: 0;
  padding: 3px 3px 3px 3px;
  border-radius: 50%;
}
.laptop {
  height: 112px;
  width: 220px;
  margin-left: -15px;
  /* padding-left: 9px; */
  z-index: 0;
  position: relative;
  margin-top: -15px;
}
.return {
  justify-content: flex-end;
  display: flex;
  align-items: flex-end;
  margin-top: 23px;
}
#returnImg {
  background-color: #ea653e;
  border-radius: 50%;
  height: 20px;
  width: 20px;
  padding: 3px 3px 3px 3px;
}
</style>
