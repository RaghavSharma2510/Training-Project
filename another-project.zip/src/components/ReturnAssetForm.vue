<template>
  <form @submit.prevent="submitReturnForm">
    <div class="modal">
      <div class="modal-content">
        <h2>Return Asset</h2>
        <div class="options">
          <label for="supervisor">Supervisor <br /></label>
          <input
            type="text"
            name="supervisor"
            id="supervisor"
            :value="trans.loaningSupervisorname"
            disabled
          />
        </div>
        <div class="options">
          <label for="student">Student <br /></label>
          <input
            type="text"
            name="student"
            id="student"
            :value="trans.studentname"
            disabled
          />
        </div>
        <div class="options">
          <label for="asset">Asset <br /></label>
          <input
            type="text"
            name="asset"
            id="asset"
            :value="trans.assetName"
            disabled
          />
        </div>
        <div class="options">
          <label for="issueDate">Issue Date <br /></label>
          <input
            type="date"
            name="issueDate"
            id="issueDate"
            :value="shortDate"
            disabled
          />
        </div>
        <div class="options">
          <label for="recSup">Receiving Supervisor <br /></label>
          <select name="recSup" id="recSup" v-model="receivingSupervisorId">
            <option value="" selected>Select</option>
            <option
              v-for="sup in supervisors"
              :key="sup.userId"
              :value="sup.id"
            >
              {{ sup.firstName }} {{ sup.lastName }}
            </option>
          </select>
        </div>
        <div class="options">
          <label for="returnDate">Issued Date <br /></label>
          <input
            type="date"
            name="returnDate"
            id="returnDate"
            v-model="returnDate"
          />
        </div>

        <p v-if="isInvalidInput">Please enter all values correctly</p>
        <p v-if="error">{{ error }}</p>
        <div class="btn">
          <button type="button" class="cancel" @click="close">Cancel</button>
          <button type="submit" class="submit">Submit</button>
        </div>
      </div>
    </div>
  </form>
</template>
<script>
export default {
  inject: ["supervisors", "close", "rerender"],
  props: ["trans"],
  data() {
    return {
      receivingSupervisorId: "",
      receivingSupervisorName: null,
      returnDate: this.getCurrentDate(),
      isInvalidInput: false,
      error: null,
      returnType: "Return",
    };
  },
  watch: {
    receivingSupervisorId(value) {
      let selectedSup = this.supervisors.find((sup) => {
        return sup.id === value;
      });
      this.receivingSupervisorName = selectedSup
        ? selectedSup.firstName + " " + selectedSup.lastName
        : "";
      // console.log(selectedSup);
    },
  },
  computed: {
    shortDate() {
      let date = new Date(this.trans.loanDate);
      // console.log(date.getFullYear());
      return (
        date.getFullYear() +
        "-" +
        ("0" + (date.getMonth() + 1)).slice(-2) +
        "-" +
        ("0" + date.getDate()).slice(-2)
      );
    },
  },
  methods: {
    getCurrentDate() {
      let today = new Date();
      let dd = String(today.getDate()).padStart(2, "0");
      let mm = String(today.getMonth() + 1).padStart(2, "0"); //January is 0!
      let yyyy = today.getFullYear();
      today = yyyy + "-" + mm + "-" + dd;
      return today;
    },
    submitReturnForm() {
      if (this.receivingSupervisorName == null || this.returnDate === null) {
        this.isInvalidInput = true;
        console.log("Galti");
        return false;
      }
      this.isInvalidInput = false;
      this.error = null;
      console.log(this.trans);
      fetch("http://localhost:3000/transactions/" + this.trans.id, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          id: this.trans.id,
          transactionType: this.returnType,
          loaningSupervisorId: this.trans.loaningSupervisorId,
          loaningSupervisorname: this.trans.loaningSupervisorname,
          studentId: this.trans.studentId,
          studentname: this.trans.studentname,
          assetId: this.trans.assetId,
          assetName: this.trans.assetName,
          loanDate: this.trans.loanDate,
          receivingSupervisorId: this.receivingSupervisorId,
          receivingSupervisorname: this.receivingSupervisorName,
          returnDate: this.returnDate,
        }),
      })
        .then((response) => {
          if (response.ok) {
            this.receivingSupervisorId = "";
            this.receivingSupervisorName = "";
            this.returnDate = null;
            this.isInvalidInput = false;
            this.error = null;
          } else {
            console.log("NHK??");
          }

          this.rerender();
          this.close();
        })
        .catch((error) => {
          console.log("Failed" + error.message);
          console.log("NHK???");
        });
    },
  },
};
</script>
<style scoped>
.modal {
  display: block; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 2; /* Sit on top */
  padding-top: 35px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0, 0, 0); /* Fallback color */
  background-color: rgba(0, 0, 0, 0.4); /* Black w/ opacity */
}
.modal-content {
  background-color: #fefffe;
  padding: 20px;
  border-radius: 20px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
  max-width: 276px;
  width: 100%;
  /* max-height: 483px;
  height: 100%; */
  height: auto;
  margin: 55px auto;
  /* z-index: 2; */
}
p {
  margin-bottom: 0;
}
h2 {
  margin-bottom: -3px;
  margin-top: 2px;
}
.options label {
  font-weight: bolder;
  font-size: 13px;
  display: block;
  text-align: start;
  margin-left: 5px;
  /* color: grey; */
  margin-bottom: 5px;
  margin-top: 14px;
}
.options {
  display: inline-flex;
  flex-direction: column;
  margin-right: 50px;
}
.options select {
  height: 35px;
  width: 266px;
  font-size: 10px;
  /* color: grey; */
  box-shadow: 0px 0.5px 1px grey;
  border-radius: 9px;
}
option {
  font-weight: bold;
  color: rgb(91, 76, 76);
  font-size: larger;
}
.options input {
  height: 33px;
  width: 261px;
  font-size: 13px;
  /* color: grey; */
  /* box-shadow: 0px 0.5px 1px grey; */
  border-radius: 9px;
}
.btn {
  display: flex;
  justify-content: space-between;
}
.cancel {
  border-radius: 4px;
  background-color: white;
  border: 1px solid grey;
  width: 139px;
  height: 37px;
  margin-top: 19px;
}
.submit {
  border-radius: 4px;
  background-color: #487172;
  border: 1px solid grey;
  width: 126px;
  height: 37px;
  margin-top: 19px;
  color: white;
  margin-left: 2px;
}
</style>
